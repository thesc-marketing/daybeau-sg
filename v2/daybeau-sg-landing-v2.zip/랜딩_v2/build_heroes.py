# 2026-11-10 Claude: 표지 시안 A·B·C를 index.html에서 표지만 바꿔 a.html·b.html·c.html로 만든다.
# 사용자 "메인 표지 조금 아쉬워 … abc다 만들어볼래? 고를게". 레퍼런스: A 써마지 FLX 화보, B 써마지 FLX 클로즈업, C 리프트성형외과 턱선.
# 사용: uv run --python 3.12 python -I build_heroes.py   (이 폴더에서)
import os, re
here = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(here, "index.html"), encoding="utf-8").read()
start = src.index('<div class="visual">')
end = src.index('<div class="head">')

PRICE = '<b class="krw"><i>₩</i>990,000</b>'
RATE = '<span class="star"><i aria-hidden="true">★</i> 4.9<small>160 reviews</small></span>'

V = {
"a": ("""<div class="visual va">
  <img src="img/hero_a.jpg" alt="">
  <div class="copy">
    <span class="loc2">Myeongdong, Seoul</span>
    <h1><span>XERF lifting,</span><b>400 shots.</b></h1>
  </div>
  <span class="ai">AI-generated model</span>
  <div class="band">
    <div><small>Event price · VAT excl.</small>PRICE</div>
    RATE
  </div>
</div>
""", """
/* 시안 A: 화보 꽉 채우기 + 왼쪽 위 두 줄 제목(써마지 FLX 화보 레퍼런스) */
.va>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;bottom:auto}
.va::after{inset:0 0 auto 0;height:45%;background:linear-gradient(rgba(20,30,35,.28),transparent)}
.va .copy{top:22px;left:22px}
.va .loc2{font-size:12px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:#fff;opacity:.9}
.va h1{color:#fff;text-shadow:0 1px 12px rgba(0,0,0,.18);font-family:var(--sans);margin-top:8px;font-size:clamp(30px,8.8vw,40px);line-height:1.12;letter-spacing:-.025em}
.va h1 span{display:block;font-weight:400}
.va h1 b{display:block;font-weight:800}
.va .ai{bottom:auto;top:12px;right:10px}
.va .band{position:absolute;left:12px;right:12px;bottom:12px;z-index:2;display:flex;align-items:flex-end;justify-content:space-between;gap:10px;background:rgba(255,255,255,.9);backdrop-filter:blur(6px);border-radius:14px;padding:12px 14px}
.va .band small{display:block;font-size:11px;color:var(--sub);margin-bottom:2px}
.va .band .star{flex-direction:column;align-items:flex-end;gap:0;font-size:18px}
.va .band .star small{margin:0;font-size:11px}
"""),
"b": ("""<div class="visual vb">
  <img src="img/hero_b.jpg" alt="">
  <span class="ai">AI-generated model</span>
  <div class="copy">
    <h1>Firmer skin,<br>in 400 shots.</h1>
    <p>XERF lifting · DAYBEAU Myeongdong</p>
  </div>
</div>
<div class="strip">
  <div><small>Shots</small><b>400</b></div>
  <div><small>Event price</small>PRICE</div>
  <div><small>Creatrip</small>RATE</div>
</div>
""", """
/* 시안 B: 얼굴 클로즈업 + 짧은 한 줄(써마지 FLX 클로즈업 레퍼런스), 숫자는 사진 밑 띠로 */
.vb>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;bottom:auto}
.vb::after{height:34%;background:linear-gradient(transparent,rgba(28,26,25,.55))}
.vb .copy{top:auto;bottom:22px;left:22px;color:#fff}
.vb h1{font-family:var(--serif);font-size:clamp(30px,8.6vw,38px);line-height:1.12;color:#fff;font-weight:500;margin:0}
.vb .copy p{font-size:12.5px;letter-spacing:.06em;text-transform:uppercase;margin-top:8px;opacity:.9}
.vb .ai{bottom:auto;top:12px}
.strip{display:grid;grid-template-columns:.7fr 1.5fr 1fr;border-bottom:1px solid var(--line)}
.strip>div{padding:12px 10px 13px;text-align:center}
.strip>div+div{border-left:1px solid var(--line)}
.strip small{display:block;font-size:11px;color:var(--sub);margin-bottom:3px}
.strip>div>b{font-size:22px;font-weight:800;color:var(--ink);line-height:1.2}
.strip .krw{font-size:20px}
.strip .sgd2{display:block;margin:0}
.strip .star{flex-direction:column;align-items:center;gap:0;font-size:18px}
.strip .star small{margin:0;font-size:11px}
"""),
"c": ("""<div class="visual vc">
  <img src="img/hero_c.jpg" alt="">
  <span class="ai">AI-generated model</span>
  <div class="copy">
    <h1><mark>A sharper jawline</mark><br>in 400 shots of XERF</h1>
    <p>Th*rmage-class RF lifting in Myeongdong, Seoul</p>
    <div class="row2"><div>PRICE</div>RATE</div>
  </div>
</div>
""", """
/* 시안 C: 턱선 크롭 + 흰 박스 키워드(리프트성형외과 레퍼런스) */
.vc>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;bottom:auto}
.vc::after{height:46%;background:linear-gradient(transparent,rgba(250,248,246,.92) 55%)}
.vc .copy{top:auto;bottom:18px;left:20px;right:20px}
.vc h1{font-family:var(--sans);font-size:clamp(25px,7.2vw,32px);line-height:1.28;font-weight:700;letter-spacing:-.02em;margin:0}
.vc mark{background:var(--ink);color:#fff;padding:0 7px;border-radius:3px;-webkit-box-decoration-break:clone;box-decoration-break:clone}
.vc .copy p{font-size:13.5px;color:var(--body);margin-top:8px}
.vc .row2{display:flex;align-items:flex-end;justify-content:space-between;gap:10px;margin-top:12px;padding-top:12px;border-top:1px solid rgba(28,26,25,.14)}
.vc .ai{bottom:auto;top:12px}
"""),
}

COMMON = """
/* 표지 공통: ₩ 기호를 작고 가늘게(굵은 ₩의 두 줄이 취소선처럼 읽힘), 별점 알약 */
.krw{font-size:30px;font-weight:800;color:var(--ink);letter-spacing:-.02em;line-height:1.1;white-space:nowrap}
.krw i{font-style:normal;font-weight:500;font-size:.62em;margin-right:2px;vertical-align:.12em}
.sgd2{font-size:14px;font-weight:700;color:var(--accent);margin-left:6px;white-space:nowrap}
.star{display:inline-flex;align-items:baseline;gap:4px;font-size:17px;font-weight:800;color:var(--ink);white-space:nowrap}
.star i{font-style:normal;color:#f2a900}
.star small{font-size:11.5px;font-weight:500;color:var(--sub);margin-left:3px}
"""

for k, (html, css) in V.items():
    html = html.replace("PRICE", PRICE).replace("RATE", RATE)
    out = src[:start] + html + "\n" + src[end:]
    out = out.replace("</style>", COMMON + css + "</style>", 1)
    open(os.path.join(here, f"{k}.html"), "w", encoding="utf-8", newline="\n").write(out)
    print(k, "ok")
