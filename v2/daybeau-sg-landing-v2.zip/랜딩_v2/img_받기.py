# 2026-11-10 Claude: 이 폴더의 img/는 git에서 빠진다(.gitignore). 다른 PC·다른 계정에서 랜딩을 열면 사진이 비어 보이므로
# 게시본(thesc-marketing/daybeau-sg 공개 저장소의 v2/img)에서 사진을 받아 img/에 채운다. 이미 있는 파일은 건너뛴다.
# 사용(이 폴더에서): uv run --python 3.12 python -I img_받기.py      (윈도우·맥 같음)
import json, os, urllib.request

here = os.path.dirname(os.path.abspath(__file__))
dst = os.path.join(here, "img")
os.makedirs(dst, exist_ok=True)
api = "https://api.github.com/repos/thesc-marketing/daybeau-sg/contents/v2/img"
req = urllib.request.Request(api, headers={"User-Agent": "landing-img-sync"})
items = json.load(urllib.request.urlopen(req))
got = skip = 0
for it in items:
    if it.get("type") != "file":
        continue
    out = os.path.join(dst, it["name"])
    if os.path.exists(out):
        skip += 1
        continue
    data = urllib.request.urlopen(urllib.request.Request(it["download_url"], headers={"User-Agent": "landing-img-sync"})).read()
    open(out, "wb").write(data)
    got += 1
    print("받음", it["name"], f"{len(data)//1024}KB")
print(f"끝: 새로 받음 {got}개, 이미 있음 {skip}개 → {dst}")
